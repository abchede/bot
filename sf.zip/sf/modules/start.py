from sf import *

@bot.on(events.NewMessage(pattern=r"(?:.start|/start)$"))
@bot.on(events.CallbackQuery(data=b'start'))
async def start(event):
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("Akses Ditolak", alert=True)
		except:
			await event.reply("Akses Ditolak")
	elif val == "true":
		
		datamem = f'cat /usr/bin/kyt/database.db | grep "USER" | wc -l'
		datam = subprocess.check_output(datamem, shell=True).decode("ascii")

		msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**» Your ID :** `{sender.id}`
**» Username :** @{sender.username}
**» Email :** `{sender.username}@sfvpn.net`
━━━━━━━━━━━━━━━━━━━━━━━
**» Menu [ /menu ]**
🤖 **» @abecasdee**
👥 **» Member :** [ `{datam.strip()}` ]
━━━━━━━━━━━━━━━━━━━━━━━
"""
		x = await event.edit(msg)
		if not x:
			await event.reply(msg)

