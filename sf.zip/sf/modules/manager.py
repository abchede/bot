from sf import *

@bot.on(events.NewMessage(pattern=r"(?:.manager|/manager)$"))
@bot.on(events.CallbackQuery(data=b'manager'))
async def manager(event):
	inline = [
[Button.inline(" SSH MENU ","ssh")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("Akses Ditolak", alert=True)
		except:
			await event.reply("Akses Ditolak")
	elif val == "true":
		
		datamem = f'cat /root/sf/database.db | grep "USER" | wc -l'
		datam = subprocess.check_output(datamem, shell=True).decode("ascii")

		msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━━**
**        __❰ MEMBER PANEL MENU ❱__ **
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Your ID :** `{sender.id}`
**» Username :** @{sender.username}
**» Email :** `{sender.username}@sfvpn.net`
**» Balance :** IDR. `15980`
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Bot Uptime :** {uptime}
**━━━━━━━━━━━━━━━━━━━━━━━**
"""
		x = await event.edit(msg,buttons=inline)
		if not x:
			await event.reply(msg,buttons=inline)
