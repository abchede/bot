from sf import *

@bot.on(events.CallbackQuery(data=b'server'))
async def server(event):
	async def server_(event):
		inline = [
[Button.inline(" SG DIGITAL OCEAN ","do"),
Button.inline(" SG AKAMAI","akamai")],
[Button.inline("⟪ Back To Menu ⟫","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━━**
**                      ⟨ SSH Menu ⟩**
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Service:** `SSH`

**» 🇸🇬 SG - AKAMAI : 10K/BULAN**
**» 🇮🇩 ID - AKAMAI : 10K/BULAN**
**» 🇸🇬 SG - DIGITAL OCEAN : 10K/BULAN**
**» 🇮🇩 ID - DIGITAL OCEAN : 10K/BULAN**
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Total Akun DO Dibuat :** `0`
**» Total Akun Akamai Dibuat :** `0`
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Bot Uptime :** `{uptime}`
**» 🤖@abecasdee**
**━━━━━━━━━━━━━━━━━━━━━━━**
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await server_(event)
	else:
		await event.answer("Access Denied🤣",alert=True)
		
@bot.on(events.CallbackQuery(data=b'do-ssh'))
async def dossh(event):
	async def dossh_(event):
		inline = [
[Button.inline(" Trial SSH ","trial-do"),
Button.inline(" Create SSH ","create-do")],
[Button.inline("⟪ Back To Menu ⟫","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━━**
**                      ⟨ SSH Menu ⟩**
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Service:** `SSH`

**» 🇸🇬 SG - DIGITAL OCEAN : 10K/BULAN**
**» 🇮🇩 ID - DIGITAL OCEAN : 10K/BULAN**
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Total Akun DO Dibuat :** `0`
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Bot Uptime :** `{uptime}`
**» 🤖@abecasdee**
**━━━━━━━━━━━━━━━━━━━━━━━**
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await dossh_(event)
	else:
		await event.answer("Access Denied🤣",alert=True)
		
@bot.on(events.CallbackQuery(data=b'akamai'))
async def akamai(event):
	async def akamai_(event):
		inline = [
[Button.inline(" Trial SSH ","trial-akamai"),
Button.inline(" Create SSH ","create-akamai")],
[Button.inline("⟪ Back To Menu ⟫","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━━**
**                      ⟨ SSH Menu ⟩**
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Service:** `SSH`

**» 🇸🇬 SG - AKAMAI : 10K/BULAN**
**» 🇮🇩 ID - AKAMAI : 10K/BULAN**
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Total Akun Akamai Dibuat :** `0`
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Bot Uptime :** `{uptime}`
**» 🤖@abecasdee**
**━━━━━━━━━━━━━━━━━━━━━━━**
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await akamai_(event)
	else:
		await event.answer("Access Denied🤣",alert=True)

@bot.on(events.CallbackQuery(data=b'trial-do'))
async def trialdo(event):
	async def trialdo_(event):
		user = "trialX"+str(random.randint(100,1000))
		pw = "1"
		exp = "1"
		cmd = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user}'
		try:
			subprocess.check_output(cmd,shell=True)
		except:
			await event.respond("**User Already Exist**")
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			msg = f"""
**━━━━━━━━━━━━━━━━**
**⟨ Trial SSH Account ⟩**
**━━━━━━━━━━━━━━━━**
**» Host:** `{DOMAIN}`
**» Username:** `{user.strip()}`
**» Password:** `{pw.strip()}`
**━━━━━━━━━━━━━━━━**
**» OpenSSH:** `22`
**» SSL/TLS:** `222`, `777`, `443`
**» Dropbear:** `109`,`143`
**» WS SSL:** `443`
**» WS HTTP:** `80`
**» Squid:** `8080`, `3128` `(Limit To IP Server)`
**» BadVPN UDPGW:** `7100` **-** `7300`
**━━━━━━━━━━━━━━━━**
**⟨ Payload WS CDN ⟩**
`GET / HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Connection: Keep-Alive[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]`
**━━━━━━━━━━━━━━━━**
**» 🗓Expired Until:** `{later}`
**» 🤖@abecasdee**
**━━━━━━━━━━━━━━━━**
"""
			await event.respond(f"""
**» SUCCES CREATE**
**» DONE**
""",buttons=[[Button.inline("⟪ Back To Menu ⟫","menu")]])
			await event.respond(msg,buttons=inline)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trialdo_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
		
@bot.on(events.CallbackQuery(data=b'create-do'))
async def createdo(event):
	async def createdo_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as pw:
			await event.respond("**Password:**")
			pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw = (await pw).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond("**Choose Expiry Day**",buttons=[
[Button.inline("• 3 Day 2,5K •","3"),
Button.inline("• 7 Day 5K •","7")],
[Button.inline("• 30 Day 10K •","30"),
Button.inline("• 60 Day 20K •","60")]])
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
		cmd = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user}'
		try:
			subprocess.check_output(cmd,shell=True)
		except:
			await event.respond("**User Already Exist**")
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			msg = f"""
**━━━━━━━━━━━━━━━━**
**⟨ SSH Account ⟩**
**━━━━━━━━━━━━━━━━**
**» Host:** `{DOMAIN}`
**» Username:** `{user.strip()}`
**» Password:** `{pw.strip()}`
**━━━━━━━━━━━━━━━━**
**» OpenSSH:** `22`
**» SSL/TLS:** `222`, `777`, `443`
**» Dropbear:** `109`,`143`
**» WS SSL:** `443`
**» WS HTTP:** `80`
**» Squid:** `8080`, `3128` `(Limit To IP Server)`
**» BadVPN UDPGW:** `7100` **-** `7300`
**━━━━━━━━━━━━━━━━**
**⟨ Payload WS CDN ⟩**
`GET / HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Connection: Keep-Alive[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]`
**━━━━━━━━━━━━━━━━**
**» 🗓Expired Until:** `{later}`
**» 🤖@abecasdee**
**━━━━━━━━━━━━━━━━**
"""
			await event.respond(f"""
**» SUCCES CREATE**
**» DONE**
""",buttons=[[Button.inline("⟪ Back To Menu ⟫","menu")]])
			await event.respond(msg,buttons=inline)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await createdo_(event)
	else:
		await event.answer("Akses Ditolak😂",alert=True)
		
@bot.on(events.CallbackQuery(data=b'trial-akamai'))
async def trialakamai(event):
	async def trialakamai_(event):
		user = "trialX"+str(random.randint(100,1000))
		pw = "1"
		exp = "1"
		cmd = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user}'
		try:
			subprocess.check_output(cmd,shell=True)
		except:
			await event.respond("**User Already Exist**")
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			msg = f"""
**━━━━━━━━━━━━━━━━**
**⟨ Trial SSH Account ⟩**
**━━━━━━━━━━━━━━━━**
**» Host:** `{DOMAIN}`
**» Username:** `{user.strip()}`
**» Password:** `{pw.strip()}`
**━━━━━━━━━━━━━━━━**
**» OpenSSH:** `22`
**» SSL/TLS:** `222`, `777`, `443`
**» Dropbear:** `109`,`143`
**» WS SSL:** `443`
**» WS HTTP:** `80`
**» Squid:** `8080`, `3128` `(Limit To IP Server)`
**» BadVPN UDPGW:** `7100` **-** `7300`
**━━━━━━━━━━━━━━━━**
**⟨ Payload WS CDN ⟩**
`GET / HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Connection: Keep-Alive[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]`
**━━━━━━━━━━━━━━━━**
**» 🗓Expired Until:** `{later}`
**» 🤖@abecasdee**
**━━━━━━━━━━━━━━━━**
"""
			await event.respond(f"""
**» SUCCES CREATE**
**» DONE**
""",buttons=[[Button.inline("⟪ Back To Menu ⟫","menu")]])
			await event.respond(msg,buttons=inline)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trialakamai_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
		
@bot.on(events.CallbackQuery(data=b'create-akamai'))
async def createakamai(event):
	async def createakamai_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as pw:
			await event.respond("**Password:**")
			pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw = (await pw).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond("**Choose Expiry Day**",buttons=[
[Button.inline("• 3 Day 2,5K •","3"),
Button.inline("• 7 Day 5K •","7")],
[Button.inline("• 30 Day 10K •","30"),
Button.inline("• 60 Day 20K •","60")]])
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
		cmd = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user}'
		try:
			subprocess.check_output(cmd,shell=True)
		except:
			await event.respond("**User Already Exist**")
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			msg = f"""
**━━━━━━━━━━━━━━━━**
**⟨ SSH Account ⟩**
**━━━━━━━━━━━━━━━━**
**» Host:** `{DOMAIN}`
**» Username:** `{user.strip()}`
**» Password:** `{pw.strip()}`
**━━━━━━━━━━━━━━━━**
**» OpenSSH:** `22`
**» SSL/TLS:** `222`, `777`, `443`
**» Dropbear:** `109`,`143`
**» WS SSL:** `443`
**» WS HTTP:** `80`
**» Squid:** `8080`, `3128` `(Limit To IP Server)`
**» BadVPN UDPGW:** `7100` **-** `7300`
**━━━━━━━━━━━━━━━━**
**⟨ Payload WS CDN ⟩**
`GET / HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Connection: Keep-Alive[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]`
**━━━━━━━━━━━━━━━━**
**» 🗓Expired Until:** `{later}`
**» 🤖@abecasdee**
**━━━━━━━━━━━━━━━━**
"""
			await event.respond(f"""
**» SUCCES CREATE**
**» DONE**
""",buttons=[[Button.inline("⟪ Back To Menu ⟫","menu")]])
			await event.respond(msg,buttons=inline)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await createakamai_(event)
	else:
		await event.answer("Akses Ditolak😂",alert=True)
		
		